from django.apps import AppConfig


class VisitConfig(AppConfig):
    name = 'visit'
